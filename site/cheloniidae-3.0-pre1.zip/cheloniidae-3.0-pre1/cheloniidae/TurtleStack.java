// Cheloniidae Turtle Graphics
// Created by Spencer Tipping and licensed under the terms of the MIT source code license

package cheloniidae;

import java.util.Stack;

public class TurtleStack extends Stack<TurtleState> {
  
}
