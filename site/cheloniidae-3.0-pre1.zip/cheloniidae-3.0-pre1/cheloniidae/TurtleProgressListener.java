// Cheloniidae Turtle Graphics
// Created by Spencer Tipping and licensed under the terms of the MIT source code license

package cheloniidae;

public interface TurtleProgressListener {
  public void turtleProgress (Turtle t);
}
