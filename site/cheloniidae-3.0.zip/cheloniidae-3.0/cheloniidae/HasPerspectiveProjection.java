package cheloniidae;

public interface HasPerspectiveProjection {
  public double depth (Viewport v);
}
