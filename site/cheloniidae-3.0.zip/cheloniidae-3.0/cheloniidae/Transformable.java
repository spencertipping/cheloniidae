package cheloniidae;

public interface Transformable<T> {
  public T map (Transformation<T> transformation);
}
