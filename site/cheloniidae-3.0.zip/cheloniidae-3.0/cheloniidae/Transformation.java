package cheloniidae;

public interface Transformation<T> {
  public T transform (T input);
}
