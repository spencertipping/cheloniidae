package cheloniidae;

public class StandardRotationalTurtle extends RotationalCartesianTurtle<StandardRotationalTurtle> {
  public StandardRotationalTurtle create () {return new StandardRotationalTurtle ();}
}
