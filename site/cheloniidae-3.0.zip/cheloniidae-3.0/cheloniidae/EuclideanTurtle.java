package cheloniidae;

import cheloniidae.commands.*;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

import java.util.List;
import java.util.ArrayList;
import java.util.SortedSet;
import java.util.TreeSet;

public abstract class EuclideanTurtle<T extends EuclideanTurtle> extends BasicTurtle<T>
implements SupportsPosition<T>, SupportsMove<T>, SupportsJump<T>, SupportsLineSize<T>, SupportsLineColor<T>, SupportsVisible<T>, TurtleCommand {

  public static class View extends ViewportCaching implements RenderAction {
    public final EuclideanTurtle turtle;
    public View (final EuclideanTurtle _turtle) {turtle = _turtle;}

    public double computeDepth (final Viewport v) {return v.transformPoint (turtle.position ()).length ();}

    public void render (final Viewport v) {
      // pp = perceived position, pd = perceived direction. These are the position and direction as seen by the user.
      Vector pp = v.transformPoint (turtle.position ());
      Vector pd = v.transformPoint (new Vector (turtle.position ()).add (turtle.direction ()));
      if (pp.z > 0 && pd.z > 0) {
        final double scale = 4.0 * v.scaleFactor () / pp.z;

        pp = v.projectPoint (pp);
        pd = v.projectPoint (pd);

        Graphics2D g = v.context ();
        g.setStroke (new BasicStroke ((float) (scale / 16.0)));
        g.setColor  (turtle.color ());
        g.drawOval  ((int) (pp.x - scale), (int) (pp.y - scale), (int) (scale * 2.0), (int) (scale * 2.0));
        g.drawLine  ((int) pp.x,           (int) pp.y,           (int) pd.x,          (int) pd.y);
      }
    }
  }

  public static class State extends ImmutableTurtleState implements TurtleState, TurtleCommand {
    public final Vector position;
    public final double size;
    public final Color  color;

    public State (final Vector _position, final double _size, final Color _color)
      {position = _position.clone (); size = _size; color = _color;}

    public State applyTo (final Turtle t) {
      new CommandSequence (new Position  (position),
                           new LineSize  (size),
                           new LineColor (color)).applyTo (t);
      return this;
    }
  }

  protected final List<CartesianLine> lines    = new ArrayList<CartesianLine> ();
  protected final View                view     = new View (this);
  protected final Vector              position = new Vector ();
  protected       double              size     = 0.25;
  protected       Color               color    = new Color (0.2f, 0.3f, 0.3f, 0.5f);
  protected       boolean             visible  = true;

  public Vector                  position  ()                       {return position;}
  public T                       position  (final Vector _position) {position.assign (_position); return (T) this;}
  public double                  size      ()                       {return size;}
  public T                       size      (final double _size)     {size = _size; return (T) this;}
  public T                       lineSize  (final double _size)     {return size (_size);}
  public Color                   color     ()                       {return color;}
  public T                       color     (final Color _color)     {color = _color; return (T) this;}
  public T                       lineColor (final Color _color)     {return color (_color);}
  public boolean                 visible   ()                       {return visible;}
  public T                       visible   (final boolean _visible) {visible = _visible; return (T) this;}

  public abstract Vector direction ();

  public T line (final Vector p1, final Vector p2) {lines.add (new CartesianLine (p1, p2, size, color)); return (T) this;}
  public T jump (final double distance)            {position.addScaled (this.direction (), distance); return (T) this;}
  public T move (final double distance)            {final Vector oldPosition = position.clone ();
                                                    return line (oldPosition, position.addScaled (this.direction (), distance));}

  public SortedSet<RenderAction> actions (final Viewport v) {
    final SortedSet<RenderAction> result = new TreeSet<RenderAction> (new PerspectiveComparator (v));
    if (visible) result.add (view);
    for (final RenderAction r : lines) if (v.shouldCancel ()) break;
                                       else                   result.add (r);
    return result;
  }

  public State serialize   ()                    {return new State (position, size, color);}
  public T     deserialize (final TurtleState t) {if (t instanceof TurtleCommand) ((TurtleCommand) t).applyTo (this);
                                                  else System.err.println ("EuclideanTurtle::deserialize: TurtleCommand expected, " + t.getClass ().getName () + " received.");
                                                  return (T) this;}

  public T applyTo (final Turtle t) {
    serialize ().applyTo (t);
    return (T) this;
  }

  public String toString () {return "Euclidean turtle: location = " + position ().toString () + ", direction = " + direction ().toString ();}
}
