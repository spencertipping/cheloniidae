package cheloniidae;

public interface NonDistributiveTurtleCommand extends TurtleCommand {}
