package cheloniidae;

public interface RenderAction extends HasPerspectiveProjection {
  public void render (Viewport viewport);
}
