package cheloniidae.frames;

import cheloniidae.RotationalCartesianTurtle;

public class DefaultRotationalCartesianTurtle extends RotationalCartesianTurtle<RotationalCartesianTurtle> {}
